import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  url:any="http://143.110.244.110/swagger/api/";
  userName:any;
  password:any;
  localdata:any;
  httpOptions:any


  constructor(private http : HttpClient) { 
    this.localdata = localStorage.getItem('AuthKey');
    if(localStorage.getItem('AuthKey')){
      console.log(this.localdata,"SERVICE");
      this.httpOptions={
        headers: new HttpHeaders({
          'Authorization': 'Bearer ' + this.localdata,
        })
      };
    }
    else{
        console.log("hello"); 
    }
  }


  postData(data:any){
    return this.http.post(this.url+"tempregisteruser",data)
  }
  postOTP(data:any){
    return this.http.post(this.url+"registerusers",data)
  }
  getData(){
    return this.http.get(this.url+"loginuser?username="+this.userName+"&"+"password="+this.password);
  }
  getMatchList(){
    return this.http.get(this.url+"getmatchlistagain",this.httpOptions)
  }
  getContest(id:any){
    return this.http.get(this.url+"getAllContests?matchkey="+id,this.httpOptions)
  }
  getContestByCat(matchkey:any,catid:any){
    return this.http.get(this.url+"getContestByCategory?matchkey="+matchkey+"&category_id="+catid,this.httpOptions);
  }
}
