import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContestByCatRoutingModule } from './contest-by-cat-routing.module';
import { ContestByCatComponent } from './contest-by-cat.component';


@NgModule({
  declarations: [
    ContestByCatComponent
  ],
  imports: [
    CommonModule,
    ContestByCatRoutingModule
  ]
})
export class ContestByCatModule { }
