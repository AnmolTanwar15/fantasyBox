import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-contest-by-cat',
  templateUrl: './contest-by-cat.component.html',
  styleUrls: ['./contest-by-cat.component.css']
})
export class ContestByCatComponent implements OnInit {

  matchKey:any;
  catId:any;

  constructor(private route : ActivatedRoute,private api : ApiService, private router : Router){}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params=>{
      this.matchKey=params['key'];
      this.catId=params['cat'];
    });

    this.api.getContestByCat(this.matchKey,this.catId).subscribe((res:any)=>{
      console.log(res,"RESPONSE");     
    })

  }




  onLogout(){
    localStorage.clear();
    this.router.navigate(['']);
  }
}
