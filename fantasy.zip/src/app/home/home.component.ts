import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  upcoming:any=[];
  targetDate:any=[];

  constructor(private router : Router, private api:ApiService){}


  ngOnInit(): void {
    this.api.getMatchList().subscribe((res:any)=>{
      console.log(res,"Match List");     
      this.upcoming=res[0].upcoming;
      console.log(this.upcoming,"UP");
      this.upcoming.filter((x:any)=>{
        this.targetDate.push(new Date(x.time_start));
        // this.targetTime=this.targetDate.getTime();
      })
      console.log(this.targetDate,"TIME");       
    },err=>{
      console.log(err);
    })
  }

  onLogout(){
    localStorage.clear();
    this.router.navigate(['']);
  }

  onCard(id:any){
    console.log(id,"ID");
    this.router.navigate(['contest'],{queryParams: {listId: id}});
  }
}
