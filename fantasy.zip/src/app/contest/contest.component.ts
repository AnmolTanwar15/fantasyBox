import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-contest',
  templateUrl: './contest.component.html',
  styleUrls: ['./contest.component.css']
})
export class ContestComponent implements OnInit {

  contestId:any;
  contests:any=[];
  value:any=[];
  cat:any=[]
  category:any=[];

  constructor(private router : Router, private route : ActivatedRoute, private api : ApiService){}


  ngOnInit(): void {

    this.route.queryParams.subscribe(params=>{
      this.contestId=params['listId'];
      console.log(this.contestId,"ContestId");      
    })

    this.api.getContest(this.contestId).subscribe((res:any)=>{
      console.log(res, "Contest");
      this.contests=res;
  
      this.contests.filter((x:any)=>{
        this.value.push((x.maximum_user - x.joinedusers)/x.maximum_user*100);
      })
      console.log(this.value,"VAlue");
      this.contests.filter((x:any)=>{
        x.value=0;
      });
      this.contests.filter((x:any,i:any)=>{
        x.value=(this.value[i]);
      });
      console.log(this.contests,"AQWSEDC");
      
      res.filter((x:any)=>{
        this.cat.push(x.catname);
      })  
      console.log(this.cat,"CAT");
      
      this.category = [... new Set(this.cat)];
      console.log(this.category,"CATEGORY");
      
    })
    
  }


onEntry(matchkey:any,catid:any){
  this.router.navigate(['contestByCat'],{queryParams:{key:matchkey,cat:catid}})
}

  onLogout(){
    localStorage.clear();
    this.router.navigate(['']);
  }
}
