import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContestRoutingModule } from './contest-routing.module';
import { ContestComponent } from './contest.component';
import { MaterialModule } from '../material.module';


@NgModule({
  declarations: [
    ContestComponent
  ],
  imports: [
    CommonModule,
    ContestRoutingModule,
    MaterialModule
  ]
})
export class ContestModule { }
